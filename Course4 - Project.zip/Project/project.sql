CREATE SCHEMA project;
USE project;
SELECT * FROM walmartsales_dataset;

-- Arranging the date in SQL format
ALTER TABLE walmartsales_dataset ADD COLUMN order_date DATE;
UPDATE walmartsales_dataset
SET order_date = CONCAT(SUBSTRING(Date, 7, 4),'-', 
                         SUBSTRING(Date, 4, 2),'-', 
                         SUBSTRING(Date, 1, 2));
ALTER TABLE walmartsales_dataset DROP COLUMN Date;
ALTER TABLE walmartsales_dataset rename column order_date to Date;

-- 1. Anaylyzing total sales of each branch
SELECT Branch, MONTH(Date) as Mnth, ROUND(SUM(Total),2) as Total_sales FROM walmartsales_dataset 
GROUP BY Branch,Mnth ORDER BY Branch, Mnth;

-- Finding the Branch having highest average growth rate among 3 months
with total_sales as
(
SELECT Branch, MONTH(Date) as Mnth, ROUND(SUM(Total),2) as Total_sales FROM walmartsales_dataset 
GROUP BY Branch,Mnth ORDER BY Branch, Mnth
),
sales_growth_rate AS 
(SELECT Branch, Mnth,Total_sales,
ROUND((Total_sales-LAG(Total_sales) OVER(Partition by Branch Order by Branch,mnth))/(LAG(Total_sales) OVER(Partition by Branch Order by Branch,mnth))*100,2) as growth_rate FROM total_sales)
SELECT Branch, ROUND(AVG(growth_rate),2) as avg_growth_rate  FROM sales_growth_rate GROUP BY Branch ORDER BY avg_growth_rate DESC;

-- 2. Finding the Profit of each Product Line for Each Branch  
CREATE TABLE profit_margin as
(SELECT Branch, Product_line, ROUND(SUM(cogs-gross_income),2) as profit FROM walmartsales_dataset 
GROUP BY Branch, Product_line ORDER BY Branch, Profit DESC);
SELECT * FROM profit_margin;

-- Finding the Most Profitable Product Line for Each Branch  
SELECT Branch,Product_line, Profit FROM profit_margin WHERE profit IN (SELECT MAX(profit) FROM profit_margin GROUP BY Branch);

-- 3. Calculating total spents for each customer
CREATE TABLE customer_spents as
(SELECT Customer_ID,ROUND(SUM(Total),2) as Total_pur_amt 
FROM walmartsales_dataset GROUP BY Customer_ID ORDER BY Customer_ID);

SELECT * FROM customer_spents;

-- Analyzing Customer Segmentation Based on Spending 
ALTER TABLE Customer_spents
ADD customer_classification VARCHAR(10);
UPDATE Customer_spents SET customer_classification=
CASE 
	WHEN Total_pur_amt > 23000 THEN 'High'
	WHEN Total_pur_amt BETWEEN 20000 AND 23000 THEN 'Medium'
	ELSE 'Low'
END;
SELECT * FROM customer_spents;

-- 4. Detecting Anomalies in Sales Transactions
WITH productline as
(SELECT Product_line,ROUND(SUM(Total),2) as Total_sales, ROUND(AVG(Total),2) as avg_sales, ROUND(STD(Total),2) as std_sales 
FROM walmartsales_dataset
GROUP BY Product_line ORDER BY Product_line),
anomaly as
(SELECT ws.Invoice_ID, ws.Product_line,
CASE
	WHEN (ws.Total-pl.avg_sales)/ pl.std_sales>2.5 THEN 'High Anomaly' -- z-score calculation formula
	WHEN (ws.Total-pl.avg_sales)/ pl.std_sales>2 THEN 'Low Anomaly'
	ELSE 'Normal'
END AS AnomalyStatus
FROM Walmartsales_dataset ws
JOIN productline pl on ws.Product_line=pl.Product_line)
SELECT * FROM anomaly WHERE AnomalyStatus IN('High Anomaly','Low Anomaly') ORDER BY AnomalyStatus;

-- 5. No. of payments done by different Payment Methods in all Cities
SELECT City, Payment, COUNT(Payment) as No_of_payments FROM walmartsales_dataset GROUP BY City, Payment ORDER BY City, No_of_payments DESC;

-- Most Popular Payment Method by City
WITH highest_payments as
(
SELECT City, Payment, COUNT(Payment) as No_of_payments FROM walmartsales_dataset GROUP BY City, Payment ORDER BY City, No_of_payments DESC
)
SELECT City, Payment, No_of_payments FROM highest_payments WHERE No_of_payments 
IN (SELECT MAX(No_of_Payments) FROM Highest_payments GROUP BY City);

-- 6. Monthly Sales Distribution by Gender
SELECT Month(Date) as mnth, Gender, COUNT(Gender) as Gender_count, ROUND(SUM(Total),2) as total_sales FROM walmartsales_dataset GROUP BY mnth,Gender ORDER BY mnth;

-- 7. No of customers of each Product Line by Customer Type 
SELECT Customer_type, product_line, COUNT(Product_line) as no_of_customers FROM walmartsales_dataset
GROUP BY Customer_type,product_line ORDER BY CUstomer_type, no_of_customers DESC;

-- Best Product Line by Customer Type 
with best_product_line as
(
SELECT Customer_type, product_line, COUNT(Product_line) as no_of_customers FROM walmartsales_dataset
GROUP BY Customer_type,product_line ORDER BY CUstomer_type, no_of_customers DESC
)
SELECT * FROM best_product_line WHERE no_of_customers 
IN (SELECT MAX(no_of_customers) FROM best_product_line GROUP BY Customer_type);

-- 8. Identifying Repeat Customers 
CREATE TABLE Repeat_customers as SELECT DISTINCT Customer_ID FROM walmartsales_dataset;
ALTER TABLE Repeat_customers ADD COLUMN IsRepeatCustomer BOOLEAN DEFAULT FALSE;

UPDATE repeat_customers
SET IsRepeatCustomer = TRUE
WHERE Customer_ID IN (
    SELECT DISTINCT Customer_ID
    FROM (
        SELECT 
            ws1.Customer_ID
        FROM walmartsales_dataset ws1
        JOIN walmartsales_dataset ws2
            ON ws1.Customer_ID = ws2.Customer_ID 
           AND ws2.Date > ws1.Date
        WHERE DATEDIFF(ws2.Date, ws1.Date) <= 30
    ) as RepeatCustomers
);

SELECT * FROM repeat_customers ORDER BY Customer_ID;

-- 9. Finding Top 5 Customers by Sales Volume
SELECT Customer_ID,ROUND(SUM(Total),2) as revenue FROM walmartsales_dataset GROUP BY Customer_ID ORDER BY revenue DESC LIMIT 5;

-- 10. Analyzing Sales Trends by Day of the Week 
SELECT dayname(Date) as day, ROUND(SUM(Total),2) as revenue FROM walmartsales_dataset GROUP BY day ORDER BY revenue DESC;




